export class LoginPageObjects {
  txtbox_username = '//input[@placeholder="User name"]';
  txtbox_password = '//input[@placeholder="Password"]';
  button_login = '(//button[@class="loginButton"])[1]';
}
