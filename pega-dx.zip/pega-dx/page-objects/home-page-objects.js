export class HomePageObjects {
    dropdown_launchPortal = "//a[@title='Launch Portal']";
    option_caseWorker = "//li[contains(@class, 'menu-item')]/a[.//span[text()='Case Worker']]";    
}
